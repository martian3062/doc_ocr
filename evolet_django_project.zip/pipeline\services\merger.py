"""
Merger — Combine all mentions per patient into final records.

Ported from notebook Cell 12.
"""
import logging
from collections import defaultdict
from typing import Any, Dict, List

from .pdf_extractor import normalize_text
from . import config

logger = logging.getLogger("pipeline")


def merge_mentions(mentions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Deduplicate and merge mentions by (category, label, value, date)."""
    merged = {}
    for m in mentions:
        if not isinstance(m, dict):
            continue
        category = normalize_text(m.get("category", "")) or "unknown"
        label = normalize_text(m.get("label", ""))
        value = normalize_text(m.get("normalized_value", "")) or normalize_text(
            m.get("value", "")
        )
        date_text = normalize_text(m.get("date_text", ""))
        key = (category.lower(), label.lower(), value.lower(), date_text.lower())

        cur = {
            "category": category,
            "label": label or category,
            "value": normalize_text(m.get("value", "")) or value,
            "normalized_value": value,
            "date_text": date_text,
            "certainty": str(m.get("certainty", "unknown")).lower(),
            "attributes": (
                m.get("attributes", {})
                if isinstance(m.get("attributes", {}), dict)
                else {}
            ),
            "source_pages": sorted(set(m.get("source_pages", []))),
            "evidence_ids": sorted(set(m.get("evidence_ids", []))),
            "evidence_quote": normalize_text(m.get("evidence_quote", "")),
            "origins": [m.get("origin", "unknown")],
        }

        if key not in merged:
            merged[key] = cur
        else:
            old = merged[key]
            old["source_pages"] = sorted(
                set(old["source_pages"]) | set(cur["source_pages"])
            )
            old["evidence_ids"] = sorted(
                set(old["evidence_ids"]) | set(cur["evidence_ids"])
            )
            old["origins"] = sorted(set(old["origins"]) | set(cur["origins"]))
            if not old["evidence_quote"] and cur["evidence_quote"]:
                old["evidence_quote"] = cur["evidence_quote"]
            if not old["attributes"] and cur["attributes"]:
                old["attributes"] = cur["attributes"]

    out = list(merged.values())
    out.sort(
        key=lambda x: (x["category"], x["date_text"], x["label"], x["normalized_value"])
    )
    return out


def group_mentions(
    mentions: List[Dict[str, Any]],
) -> Dict[str, List[Dict[str, Any]]]:
    """Group mentions by category."""
    groups = defaultdict(list)
    for m in mentions:
        groups[m["category"]].append(m)
    return dict(sorted(groups.items(), key=lambda x: x[0]))


def build_final_record(
    patient_code: str,
    source_pdf: str,
    page_count: int,
    note_count: int,
    all_mentions: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Build the final merged record for a patient."""
    merged = merge_mentions(all_mentions)
    grouped = group_mentions(merged)

    review_flags = []
    if not merged:
        review_flags.append("no_mentions_after_merge")

    return {
        "patient_code": patient_code,
        "source_pdf": source_pdf,
        "page_count": page_count,
        "note_count": note_count,
        "mentions": merged,
        "grouped_record": grouped,
        "review_flags": review_flags,
        "traceability": {
            "source_pages": sorted(
                set(p for m in merged for p in m.get("source_pages", []))
            ),
            "evidence_ids": sorted(
                set(e for m in merged for e in m.get("evidence_ids", []))
            ),
        },
        "stats": {
            "raw_mentions_before_merge": len(all_mentions),
            "mentions_after_merge": len(merged),
            "categories_after_merge": len(grouped),
        },
    }
