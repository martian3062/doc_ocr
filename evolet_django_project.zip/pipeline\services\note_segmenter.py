"""
Note Segmenter — Split page text into clinical notes, score them, triage.

Ported from notebook Cell 4 split_into_notes + triage logic.
"""
import re
import logging
from typing import Any, Dict, List

from . import config
from .pdf_extractor import normalize_text, word_count, text_hash

logger = logging.getLogger("pipeline")


def extract_dates(text: str) -> List[str]:
    hits = []
    for pat in config.DATE_PATTERNS:
        hits.extend(re.findall(pat, text, flags=re.I))
    seen, out = set(), []
    for x in hits:
        if x not in seen:
            out.append(x)
            seen.add(x)
    return out


def is_low_value_note(text: str) -> bool:
    t = normalize_text(text).lower()
    if word_count(t) < config.NOTE_MIN_WORDS:
        return True
    hits = sum(
        1 for pat in config.LOW_VALUE_PATTERNS if re.search(pat, t, flags=re.I)
    )
    if hits >= 2:
        return True
    if "prescription has been issued" in t and word_count(t) < 45:
        return True
    return False


def clinical_signal_score(text: str) -> int:
    t = normalize_text(text).lower()
    score = 0
    score += min(len(t) // 400, 4)
    score += min(len(extract_dates(t)), 3)
    for pat in config.CLINICAL_HINT_PATTERNS:
        if re.search(pat, t, flags=re.I):
            score += 1
    return score


def split_into_notes(page_num: int, text: str) -> List[Dict[str, Any]]:
    """Split page text into note-level units."""
    text = normalize_text(text)
    if not text:
        return []

    split_re = "(" + "|".join(config.SECTION_SPLIT_PATTERNS) + ")"
    parts = re.split(split_re, text, flags=re.I)

    merged = []
    cur = ""
    for chunk in parts:
        chunk = normalize_text(chunk)
        if not chunk:
            continue
        if re.match(split_re, chunk, flags=re.I):
            if cur.strip():
                merged.append(cur.strip())
            cur = chunk
        else:
            cur = (cur + "\n" + chunk).strip() if cur else chunk
    if cur.strip():
        merged.append(cur.strip())

    out = []
    for i, note_text in enumerate(merged, start=1):
        note_text = normalize_text(note_text)
        if word_count(note_text) < config.NOTE_MIN_WORDS:
            continue
        out.append(
            {
                "page_num": page_num,
                "note_ix": i,
                "note_id": f"p{page_num:04d}_n{i:03d}",
                "text": note_text,
                "hash": text_hash(note_text),
                "dates": extract_dates(note_text),
                "signal": clinical_signal_score(note_text),
                "low_value": is_low_value_note(note_text),
            }
        )
    return out


def segment_pages_to_notes(
    page_rows: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Convert page-level text into deduplicated note-level units."""
    notes = []
    seen_hashes = set()
    for row in page_rows:
        for note in split_into_notes(row["page_num"], row["text"]):
            if config.DEDUP_EXACT_NOTES and note["hash"] in seen_hashes:
                continue
            seen_hashes.add(note["hash"])
            notes.append(note)
    return notes


def triage_notes(
    notes: List[Dict[str, Any]], regex_results: Dict[str, List]
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Classify notes into resolved (handled by regex) and unresolved (need LLM).
    """
    resolved = []
    unresolved = []

    for note in notes:
        note_id = note["note_id"]
        regex_mentions = regex_results.get(note_id, [])

        if _note_needs_llm(note, regex_mentions):
            unresolved.append({**note, "regex_mentions": regex_mentions})
        else:
            resolved.append({**note, "mentions": regex_mentions})

    # Sort unresolved by signal strength, limit per patient
    unresolved = sorted(
        unresolved,
        key=lambda x: (x.get("signal", 0), word_count(x["text"])),
        reverse=True,
    )[: config.MAX_NOTES_PER_PATIENT_FOR_LLM]

    return {"resolved": resolved, "unresolved": unresolved}


def _note_needs_llm(note: Dict[str, Any], regex_mentions: List) -> bool:
    if note.get("low_value"):
        return False
    if note.get("signal", 0) < config.MIN_SIGNAL_FOR_LLM:
        return False
    if regex_mentions and len(regex_mentions) >= config.MIN_REGEX_MENTIONS_TO_SKIP_LLM:
        return False
    if not config.SEND_SHORT_NOTES_TO_LLM and word_count(note["text"]) < 40:
        return False
    return True
