"""
GPU utilities — CUDA setup, memory management, dtype detection.
"""
import gc
import logging
import torch

logger = logging.getLogger("pipeline")


def setup_gpu():
    """Enable TF32 and set matmul precision for speed on Ampere+ GPUs."""
    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        try:
            torch.set_float32_matmul_precision("high")
        except Exception:
            pass
        logger.info(
            f"GPU: {torch.cuda.get_device_name(0)} | "
            f"Memory: {torch.cuda.get_device_properties(0).total_mem / 1024**3:.1f} GB"
        )


def detect_compute_dtype():
    """Pick bfloat16 on Ampere+ (sm_80+), else float16, else float32."""
    if not torch.cuda.is_available():
        return torch.float32
    major, _ = torch.cuda.get_device_capability(0)
    return torch.bfloat16 if major >= 8 else torch.float16


def release_cuda():
    """Free GPU memory aggressively."""
    gc.collect()
    if torch.cuda.is_available():
        torch.cuda.empty_cache()
        try:
            torch.cuda.ipc_collect()
        except Exception:
            pass


def gpu_info() -> dict:
    """Return GPU status information."""
    if not torch.cuda.is_available():
        return {"available": False}
    free_b, total_b = torch.cuda.mem_get_info()
    return {
        "available": True,
        "device_name": torch.cuda.get_device_name(0),
        "total_gb": round(total_b / 1024**3, 2),
        "free_gb": round(free_b / 1024**3, 2),
        "used_gb": round((total_b - free_b) / 1024**3, 2),
        "utilization_pct": round((total_b - free_b) / total_b * 100, 1),
    }
