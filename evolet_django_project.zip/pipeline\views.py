"""
Evolet Pipeline — Views

HTMX-powered views for the dashboard, upload, patient list/detail,
pipeline runs, and QC summary.
"""
import json
import os
import shutil
import tempfile
import threading
import logging
from pathlib import Path

from django.conf import settings
from django.http import HttpResponse, JsonResponse, FileResponse
from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST, require_GET
from django.utils import timezone
from django.db.models import Q, Count, Sum

from .models import (
    Patient, PDFDocument, PipelineRun, PageLedger, NoteLedger,
    Mention, FinalRecord, ProcessingLog,
)
from .forms import PDFUploadForm, FolderImportForm, PipelineRunForm
from .services.gpu_utils import gpu_info
from .services.qc import compute_qc_metrics, compute_run_summary

logger = logging.getLogger("pipeline")


# ── Dashboard ──

def dashboard(request):
    total_patients = Patient.objects.count()
    total_pdfs = PDFDocument.objects.count()
    total_mentions = Mention.objects.count()
    recent_runs = PipelineRun.objects.all()[:5]
    active_run = PipelineRun.objects.filter(
        status__in=["pending", "extracting", "triaging", "llm_processing", "merging", "qc"]
    ).first()
    gpu = gpu_info()

    return render(request, "dashboard.html", {
        "total_patients": total_patients,
        "total_pdfs": total_pdfs,
        "total_mentions": total_mentions,
        "recent_runs": recent_runs,
        "active_run": active_run,
        "gpu": gpu,
    })


# ── Upload ──

def upload(request):
    if request.method == "POST":
        files = request.FILES.getlist("files")
        if not files:
            return render(request, "pipeline/upload.html", {
                "form": PDFUploadForm(),
                "error": "No files selected.",
            })

        imported = []
        for f in files:
            patient_code = Path(f.name).stem
            patient, _ = Patient.objects.get_or_create(
                code=patient_code,
                defaults={"display_name": patient_code},
            )
            doc = PDFDocument.objects.create(
                patient=patient,
                original_filename=f.name,
                file=f,
                source_type=PDFDocument.SourceType.UPLOAD,
                file_size_bytes=f.size,
            )
            imported.append(doc)

        if request.headers.get("HX-Request"):
            return render(request, "pipeline/partials/upload_result.html", {
                "imported": imported,
                "count": len(imported),
            })
        return redirect("pipeline:patient_list")

    return render(request, "pipeline/upload.html", {
        "form": PDFUploadForm(),
    })


# ── Folder Browser ──

def folder_browser(request):
    folder_path = request.GET.get("path", str(settings.EVOLET_DATA_DIR))
    error = None
    files = []

    try:
        p = Path(folder_path)
        if p.exists() and p.is_dir():
            for f in sorted(p.iterdir()):
                if f.is_file() and f.suffix.lower() == ".pdf":
                    already_imported = PDFDocument.objects.filter(
                        folder_path=str(f)
                    ).exists()
                    files.append({
                        "name": f.name,
                        "path": str(f),
                        "size_mb": round(f.stat().st_size / (1024 * 1024), 2),
                        "imported": already_imported,
                    })
        else:
            error = f"Directory not found: {folder_path}"
    except Exception as e:
        error = str(e)

    return render(request, "pipeline/folder_browser.html", {
        "folder_path": folder_path,
        "files": files,
        "file_count": len(files),
        "error": error,
        "form": FolderImportForm(initial={"folder_path": folder_path}),
    })


@require_POST
def import_folder(request):
    """Import all PDFs from a server-side folder."""
    folder_path = request.POST.get("folder_path", "")
    p = Path(folder_path)
    if not p.exists() or not p.is_dir():
        return JsonResponse({"error": f"Directory not found: {folder_path}"}, status=400)

    imported = 0
    for f in sorted(p.glob("*.pdf")):
        patient_code = f.stem
        if PDFDocument.objects.filter(folder_path=str(f)).exists():
            continue
        patient, _ = Patient.objects.get_or_create(
            code=patient_code,
            defaults={"display_name": patient_code},
        )
        PDFDocument.objects.create(
            patient=patient,
            original_filename=f.name,
            folder_path=str(f),
            source_type=PDFDocument.SourceType.FOLDER,
            file_size_bytes=f.stat().st_size,
        )
        imported += 1

    if request.headers.get("HX-Request"):
        return render(request, "pipeline/partials/upload_result.html", {
            "count": imported,
            "folder": folder_path,
        })
    return redirect("pipeline:folder_browser")


# ── Patient List ──

def patient_list(request):
    q = request.GET.get("q", "").strip()
    patients = Patient.objects.annotate(
        mention_count=Count("mentions"),
        doc_count=Count("documents"),
    )
    if q:
        patients = patients.filter(
            Q(code__icontains=q) | Q(display_name__icontains=q)
        )

    patients = patients.order_by("code")

    if request.headers.get("HX-Request") and request.GET.get("partial"):
        return render(request, "pipeline/partials/patient_rows.html", {
            "patients": patients,
        })

    return render(request, "pipeline/patient_list.html", {
        "patients": patients,
        "query": q,
        "total": patients.count(),
    })


# ── Patient Detail ──

def patient_detail(request, patient_id):
    patient = get_object_or_404(Patient, id=patient_id)
    documents = patient.documents.all()
    mentions = patient.mentions.all().order_by("category", "date_text")

    # Group mentions by category
    grouped = {}
    for m in mentions:
        grouped.setdefault(m.category, []).append(m)

    final_record = getattr(patient, "final_record", None)
    notes = NoteLedger.objects.filter(document__patient=patient).order_by("page_num", "note_ix")

    return render(request, "pipeline/patient_detail.html", {
        "patient": patient,
        "documents": documents,
        "mentions": mentions,
        "grouped_mentions": grouped,
        "final_record": final_record,
        "notes": notes,
        "mention_count": mentions.count(),
        "category_count": len(grouped),
    })


# ── Pipeline Runs ──

def run_list(request):
    runs = PipelineRun.objects.all()
    return render(request, "pipeline/run_list.html", {"runs": runs})


def run_detail(request, run_id):
    run = get_object_or_404(PipelineRun, id=run_id)
    logs = run.logs.all()[:50]
    return render(request, "pipeline/run_detail.html", {
        "run": run,
        "logs": logs,
    })


@require_POST
def start_run(request):
    """Start a new pipeline run in a background thread."""
    form = PipelineRunForm(request.POST)
    selected_ids = request.POST.getlist("document_ids")

    # Get documents to process
    if selected_ids:
        documents = PDFDocument.objects.filter(id__in=selected_ids)
    else:
        documents = PDFDocument.objects.all()

    if not documents.exists():
        return JsonResponse({"error": "No documents to process"}, status=400)

    run = PipelineRun.objects.create(
        name=request.POST.get("name", f"Run {timezone.now().strftime('%Y-%m-%d %H:%M')}"),
        model_id=request.POST.get("model_id", "Qwen/Qwen2.5-1.5B-Instruct"),
        use_4bit=request.POST.get("use_4bit", "on") == "on",
        total_pdfs=documents.count(),
    )
    run.documents.set(documents)

    # Run pipeline in background thread
    def _run():
        try:
            from .orchestrator import run_full_pipeline
            run_full_pipeline(run)
        except Exception as e:
            run.status = PipelineRun.Status.FAILED
            run.error_message = str(e)
            run.completed_at = timezone.now()
            run.save()
            logger.exception(f"Pipeline run failed: {e}")

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    if request.headers.get("HX-Request"):
        return redirect("pipeline:run_detail", run_id=run.id)
    return redirect("pipeline:run_detail", run_id=run.id)


# ── Run Progress (HTMX polling) ──

def run_progress(request, run_id):
    run = get_object_or_404(PipelineRun, id=run_id)
    return render(request, "pipeline/partials/run_progress.html", {"run": run})


# ── QC Summary ──

def qc_summary(request):
    final_records = FinalRecord.objects.select_related("patient").all()
    qc_rows = []
    for fr in final_records:
        qc_rows.append({
            "patient_code": fr.patient.code,
            "mention_count": fr.mention_count,
            "category_count": fr.category_count,
            "review_flags": len(fr.review_flags),
            "has_diagnosis": "diagnosis" in fr.grouped_record,
            "has_medication": "medication" in fr.grouped_record,
            "has_imaging": "imaging" in fr.grouped_record,
            "has_pathology": "pathology" in fr.grouped_record,
            "page_count": fr.page_count,
            "note_count": fr.note_count,
        })

    summary = compute_run_summary(qc_rows) if qc_rows else {}

    return render(request, "pipeline/qc_summary.html", {
        "qc_rows": qc_rows,
        "summary": summary,
    })


# ── Download ──

def download_patient_json(request, patient_id):
    patient = get_object_or_404(Patient, id=patient_id)
    mentions = list(patient.mentions.values(
        "category", "label", "value", "normalized_value",
        "date_text", "certainty", "evidence_quote", "origin",
    ))
    data = {
        "patient_code": patient.code,
        "mentions": mentions,
    }
    response = HttpResponse(
        json.dumps(data, indent=2, default=str),
        content_type="application/json",
    )
    response["Content-Disposition"] = f'attachment; filename="{patient.code}_record.json"'
    return response


def download_run_zip(request, run_id):
    run = get_object_or_404(PipelineRun, id=run_id)
    patients = Patient.objects.filter(documents__runs=run).distinct()

    with tempfile.TemporaryDirectory() as tmp_dir:
        zip_base = Path(tmp_dir) / f"evolet_run_{run.id.hex[:8]}"
        zip_base.mkdir()

        for patient in patients:
            mentions = list(patient.mentions.filter(run=run).values(
                "category", "label", "value", "normalized_value",
                "date_text", "certainty", "evidence_quote", "origin",
            ))
            data = {"patient_code": patient.code, "mentions": mentions}
            with open(zip_base / f"{patient.code}_record.json", "w") as f:
                json.dump(data, f, indent=2, default=str)

        zip_path = shutil.make_archive(str(zip_base), "zip", str(zip_base))
        return FileResponse(
            open(zip_path, "rb"),
            as_attachment=True,
            filename=f"evolet_run_{run.id.hex[:8]}.zip",
        )


# ── API endpoints for HTMX ──

def api_gpu_status(request):
    return render(request, "pipeline/partials/gpu_status.html", {"gpu": gpu_info()})
