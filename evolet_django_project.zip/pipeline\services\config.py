"""
Evolet Pipeline — Runtime Configuration

All tuneable knobs from the notebook, centralized as module-level constants
with environment-variable overrides.
"""
import os
import torch

# ── Model ──
MODEL_ID = os.environ.get("EVOLET_MODEL_ID", "Qwen/Qwen2.5-1.5B-Instruct")
FALLBACK_MODEL_ID = "HuggingFaceTB/SmolLM2-1.7B-Instruct"
USE_4BIT = os.environ.get("EVOLET_USE_4BIT", "1").strip() == "1"
LOCAL_FILES_ONLY = os.environ.get("EVOLET_LOCAL_ONLY", "0").strip() == "1"
HF_TOKEN = (
    os.environ.get("HF_TOKEN")
    or os.environ.get("HUGGING_FACE_HUB_TOKEN")
    or os.environ.get("HUGGINGFACEHUB_API_TOKEN")
)

# ── OCR ──
USE_DOCTR_OCR = True
OCR_RENDER_DPI = 130
OCR_BATCH_PAGES = 10
NATIVE_TEXT_MIN_CHARS = 120
NATIVE_TEXT_MIN_WORDS = 22
NATIVE_TEXT_MIN_ALPHA_RATIO = 0.28

# ── Note segmentation ──
NOTE_MIN_WORDS = 12
DEDUP_EXACT_NOTES = True

# ── Triage ──
MAX_NOTES_PER_PATIENT_FOR_LLM = 24
MIN_SIGNAL_FOR_LLM = 3
MIN_REGEX_MENTIONS_TO_SKIP_LLM = 3
SEND_SHORT_NOTES_TO_LLM = False

# ── Adaptive batching ──
SHORT_NOTE_WORDS = 120
MEDIUM_NOTE_WORDS = 220
LONG_NOTE_WORDS = 380

GPU_AVAILABLE = torch.cuda.is_available()

SHORT_BATCH_SIZE = 3 if GPU_AVAILABLE else 1
MEDIUM_BATCH_SIZE = 2 if GPU_AVAILABLE else 1
LONG_BATCH_SIZE = 1
XLONG_BATCH_SIZE = 1

# ── Generation ──
MAX_INPUT_TOKENS = 3584
MAX_NEW_TOKENS = 640
RETRY_MAX_NEW_TOKENS = 768
DO_SAMPLE = False

# ── Parallelism ──
MAX_WORKERS = int(os.environ.get("EVOLET_MAX_WORKERS", "4"))
SKIP_EXISTING = True

# ── Section patterns for note splitting ──
SECTION_SPLIT_PATTERNS = [
    r"\bDATE\s*:\s*\d{1,2}[./-]\d{1,2}[./-]\d{2,4}",
    r"\bCLINICAL NOTE DETAILS\b",
    r"\bPATIENT ASSESSMENT DETAILS\b",
    r"\bJOINT-CLINIC DETAILS\b",
    r"\bREMARKS DETAILS\b",
    r"\bDETAILS OF JOINT CLINIC\b",
]

LOW_VALUE_PATTERNS = [
    r"prescription has been issued by",
    r"cost certificate issued",
    r"https?://",
    r"tata memorial hospital[- ]electronic medical record",
    r"fax:",
    r"e-mail:",
]

CLINICAL_HINT_PATTERNS = [
    r"\bdiagnosis\b", r"\bcarcinoma\b", r"\brcc\b", r"\besophagus\b",
    r"\bmetast", r"\bstage\b", r"\bgrade\b", r"\bbiopsy\b",
    r"\bhistopath\b", r"\bhpr\b", r"\bihc\b", r"\bpet ct\b",
    r"\bc?ect\b", r"\bmri\b", r"\bradiotherapy\b", r"\brt\b",
    r"\bsurgery\b", r"\bnephrectomy\b", r"\bsunitinib\b",
    r"\bchemo", r"\btablet\b", r"\btab\b", r"\bplan\b",
    r"\bfollow[- ]?up\b", r"\bpain\b", r"\bcreat\b", r"\bhb\b",
    r"\bplatelet\b", r"\blymph", r"\bnodule\b", r"\blesion\b",
]

DATE_PATTERNS = [
    r"\b\d{1,2}[./-]\d{1,2}[./-]\d{2,4}\b",
    r"\b\d{1,2}\s+[A-Za-z]{3,9}\s+\d{2,4}\b",
]

# ── LLM Prompt ──
SYSTEM_PROMPT = """
You extract structured clinical mentions from one medical note.

Return exactly one JSON object with this shape:
{
  "mentions": [
    {
      "category": "",
      "label": "",
      "value": "",
      "normalized_value": "",
      "date_text": "",
      "certainty": "confirmed|possible|ruled_out|unknown",
      "attributes": {},
      "evidence_quote": ""
    }
  ]
}

Rules:
- JSON only. No markdown. No commentary.
- Max 8 mentions.
- Do not invent facts.
- evidence_quote must be a short verbatim snippet from the note.
- If no clinically useful mention exists, return {"mentions":[]}.
- Allowed categories:
  diagnosis, medication, plan, symptom, imaging, pathology, genomics,
  procedure, lab, status, follow_up, surgery, radiotherapy,
  performance_status, other
""".strip()
