"""Pipeline forms for file upload."""
from django import forms


class PDFUploadForm(forms.Form):
    """Upload one or more PDF/text files."""
    files = forms.FileField(
        widget=forms.ClearableFileInput(attrs={
            "multiple": True,
            "accept": ".pdf,.txt,.text",
            "class": "hidden",
            "id": "file-upload-input",
        }),
        required=False,
    )


class FolderImportForm(forms.Form):
    """Import PDFs from a server-side folder path."""
    folder_path = forms.CharField(
        max_length=1000,
        widget=forms.TextInput(attrs={
            "placeholder": "e.g. /home/pardeep/data/TMH_Patient_Reports",
            "class": "w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-cyan-500 focus:border-transparent",
        }),
    )


class PipelineRunForm(forms.Form):
    """Configure a new pipeline run."""
    name = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            "placeholder": "Run name (optional)",
            "class": "w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white placeholder-gray-500 focus:ring-2 focus:ring-cyan-500",
        }),
    )
    model_id = forms.CharField(
        max_length=200,
        initial="Qwen/Qwen2.5-1.5B-Instruct",
        widget=forms.TextInput(attrs={
            "class": "w-full px-4 py-3 bg-gray-800 border border-gray-600 rounded-lg text-white focus:ring-2 focus:ring-cyan-500",
        }),
    )
    use_4bit = forms.BooleanField(
        initial=True,
        required=False,
        widget=forms.CheckboxInput(attrs={
            "class": "h-4 w-4 text-cyan-600 bg-gray-800 border-gray-600 rounded focus:ring-cyan-500",
        }),
    )
