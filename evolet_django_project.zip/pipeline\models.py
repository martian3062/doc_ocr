"""
Evolet Pipeline — Database Models

Mirrors the notebook's artifact structure:
  Patient → PDFDocument → PageLedger → NoteLedger → Mention → FinalRecord
"""
import uuid
from django.db import models
from django.utils import timezone


class Patient(models.Model):
    """One patient — derived from the PDF filename stem."""
    code = models.CharField(max_length=300, unique=True, db_index=True)
    display_name = models.CharField(max_length=300, blank=True)
    profile_image = models.ImageField(
        upload_to="profile_images/", blank=True, null=True
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["code"]

    def __str__(self):
        return self.display_name or self.code


class PDFDocument(models.Model):
    """One PDF file — can come from folder import or user upload."""
    class SourceType(models.TextChoices):
        FOLDER = "folder", "Imported from folder"
        UPLOAD = "upload", "Uploaded by user"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    patient = models.ForeignKey(
        Patient, on_delete=models.CASCADE, related_name="documents"
    )
    original_filename = models.CharField(max_length=500)
    file = models.FileField(upload_to="pdfs/", blank=True)
    folder_path = models.CharField(max_length=1000, blank=True,
                                   help_text="Absolute path for folder-imported PDFs")
    source_type = models.CharField(
        max_length=10, choices=SourceType.choices, default=SourceType.FOLDER
    )
    page_count = models.IntegerField(default=0)
    file_size_bytes = models.BigIntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return self.original_filename


class PipelineRun(models.Model):
    """One pipeline execution across one or more PDFs."""
    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        EXTRACTING = "extracting", "Extracting text"
        TRIAGING = "triaging", "Triaging notes"
        LLM_PROCESSING = "llm_processing", "LLM processing"
        MERGING = "merging", "Merging mentions"
        QC = "qc", "Quality check"
        COMPLETED = "completed", "Completed"
        FAILED = "failed", "Failed"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(max_length=200, blank=True)
    status = models.CharField(
        max_length=20, choices=Status.choices, default=Status.PENDING
    )
    model_id = models.CharField(max_length=200, default="Qwen/Qwen2.5-1.5B-Instruct")
    use_4bit = models.BooleanField(default=True)

    # Progress tracking
    total_pdfs = models.IntegerField(default=0)
    processed_pdfs = models.IntegerField(default=0)
    total_notes = models.IntegerField(default=0)
    resolved_notes = models.IntegerField(default=0)
    unresolved_notes = models.IntegerField(default=0)
    total_mentions = models.IntegerField(default=0)

    # Timing
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    error_message = models.TextField(blank=True)

    created_at = models.DateTimeField(auto_now_add=True)

    # Link to documents
    documents = models.ManyToManyField(PDFDocument, related_name="runs", blank=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"Run {self.id.hex[:8]} — {self.status}"

    @property
    def progress_percent(self):
        if self.total_pdfs == 0:
            return 0
        return int((self.processed_pdfs / self.total_pdfs) * 100)

    @property
    def duration_seconds(self):
        if not self.started_at:
            return 0
        end = self.completed_at or timezone.now()
        return (end - self.started_at).total_seconds()


class PageLedger(models.Model):
    """Per-page extraction result from a PDF."""
    document = models.ForeignKey(
        PDFDocument, on_delete=models.CASCADE, related_name="pages"
    )
    page_num = models.IntegerField()
    text = models.TextField(blank=True)
    selected_source = models.CharField(max_length=10, default="native")
    char_count = models.IntegerField(default=0)
    word_count = models.IntegerField(default=0)
    alpha_ratio = models.FloatField(default=0.0)
    need_ocr = models.BooleanField(default=False)

    class Meta:
        unique_together = ("document", "page_num")
        ordering = ["document", "page_num"]

    def __str__(self):
        return f"Page {self.page_num} of {self.document}"


class NoteLedger(models.Model):
    """Per-note segmented text from a page."""
    document = models.ForeignKey(
        PDFDocument, on_delete=models.CASCADE, related_name="notes"
    )
    note_id = models.CharField(max_length=20)
    page_num = models.IntegerField()
    note_ix = models.IntegerField()
    text = models.TextField()
    text_hash = models.CharField(max_length=32)
    signal_score = models.IntegerField(default=0)
    is_low_value = models.BooleanField(default=False)
    needs_llm = models.BooleanField(default=False)
    is_resolved = models.BooleanField(default=False)

    class Meta:
        ordering = ["document", "page_num", "note_ix"]

    def __str__(self):
        return f"Note {self.note_id} of {self.document}"


class Mention(models.Model):
    """One extracted clinical mention — from regex or LLM."""
    class Origin(models.TextChoices):
        REGEX = "regex", "Deterministic regex"
        LLM = "llm", "LLM extraction"
        MERGED = "merged", "Merged"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    patient = models.ForeignKey(
        Patient, on_delete=models.CASCADE, related_name="mentions"
    )
    document = models.ForeignKey(
        PDFDocument, on_delete=models.CASCADE, related_name="mentions",
        null=True, blank=True
    )
    run = models.ForeignKey(
        PipelineRun, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="mentions"
    )
    note = models.ForeignKey(
        NoteLedger, on_delete=models.SET_NULL, null=True, blank=True,
        related_name="mentions"
    )

    category = models.CharField(max_length=50, db_index=True)
    label = models.CharField(max_length=200)
    value = models.TextField()
    normalized_value = models.TextField(blank=True)
    date_text = models.CharField(max_length=100, blank=True)
    certainty = models.CharField(max_length=20, default="unknown")
    attributes = models.JSONField(default=dict, blank=True)
    evidence_quote = models.TextField(blank=True)
    source_pages = models.JSONField(default=list, blank=True)
    evidence_ids = models.JSONField(default=list, blank=True)
    origin = models.CharField(
        max_length=10, choices=Origin.choices, default=Origin.REGEX
    )

    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["category", "date_text", "label"]

    def __str__(self):
        return f"[{self.category}] {self.label}: {self.value[:60]}"


class FinalRecord(models.Model):
    """Merged patient-level record after the full pipeline."""
    patient = models.OneToOneField(
        Patient, on_delete=models.CASCADE, related_name="final_record"
    )
    run = models.ForeignKey(
        PipelineRun, on_delete=models.SET_NULL, null=True, blank=True
    )
    page_count = models.IntegerField(default=0)
    note_count = models.IntegerField(default=0)
    mention_count = models.IntegerField(default=0)
    category_count = models.IntegerField(default=0)
    grouped_record = models.JSONField(default=dict)
    review_flags = models.JSONField(default=list)
    traceability = models.JSONField(default=dict)
    stats = models.JSONField(default=dict)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["patient__code"]

    def __str__(self):
        return f"Final record for {self.patient}"


class ProcessingLog(models.Model):
    """Pipeline execution log entry."""
    class Level(models.TextChoices):
        INFO = "info", "Info"
        WARNING = "warning", "Warning"
        ERROR = "error", "Error"

    run = models.ForeignKey(
        PipelineRun, on_delete=models.CASCADE, related_name="logs",
        null=True, blank=True
    )
    level = models.CharField(
        max_length=10, choices=Level.choices, default=Level.INFO
    )
    stage = models.CharField(max_length=50, blank=True)
    message = models.TextField()
    details = models.JSONField(default=dict, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["-created_at"]

    def __str__(self):
        return f"[{self.level}] {self.stage}: {self.message[:80]}"
