"""
Photo Extractor — Extract patient profile photos from PDFs.

Ported from notebook Cells 29-31.
"""
import io
import re
import logging
from pathlib import Path
from typing import Any, Dict, Optional

import fitz
from PIL import Image, ImageChops

logger = logging.getLogger("pipeline")


def safe_stem(name: str) -> str:
    name = str(name or "").strip()
    name = re.sub(r"[^\w.\- ]+", "_", name)
    name = re.sub(r"\s+", "_", name).strip("._ ")
    return name or "unknown_pdf"


def _trim_white_border(img: Image.Image) -> Image.Image:
    if img.mode != "RGB":
        img = img.convert("RGB")
    bg = Image.new("RGB", img.size, (255, 255, 255))
    diff = ImageChops.difference(img, bg)
    bbox = diff.getbbox()
    if bbox:
        cropped = img.crop(bbox)
        if cropped.size[0] >= 20 and cropped.size[1] >= 20:
            return cropped
    return img


def _pick_patient_photo(page) -> Optional[Dict[str, Any]]:
    """Find the small portrait image in the left-middle area of page 1."""
    try:
        infos = page.get_image_info(xrefs=True)
    except Exception:
        infos = []

    pw = float(page.rect.width)
    ph = float(page.rect.height)
    candidates = []

    for info in infos:
        xref = info.get("xref", 0)
        bbox = info.get("bbox")
        if not xref or not bbox:
            continue

        rect = fitz.Rect(bbox)
        bw, bh = float(rect.width), float(rect.height)
        if bw <= 0 or bh <= 0:
            continue

        area_ratio = (bw * bh) / max(pw * ph, 1.0)
        aspect = bw / max(bh, 1.0)

        if rect.y0 < 0.12 * ph:
            continue
        if rect.x0 > 0.35 * pw:
            continue
        if not (0.0008 <= area_ratio <= 0.05):
            continue
        if not (0.35 <= aspect <= 1.35):
            continue

        score = 0.0
        if rect.x0 <= 0.25 * pw:
            score += 3
        if 0.18 * ph <= rect.y0 <= 0.50 * ph:
            score += 3
        if bh >= bw:
            score += 2
        score += min(area_ratio * 100, 2)

        candidates.append({"score": score, "xref": xref, "bbox": bbox})

    if not candidates:
        return None
    candidates.sort(key=lambda x: x["score"], reverse=True)
    return candidates[0]


def extract_profile_photo(pdf_path: str, output_path: str) -> Dict[str, Any]:
    """
    Extract the patient profile photo from a PDF.
    Returns metadata dict.
    """
    meta = {
        "photo_found": False,
        "method": "",
        "error": "",
    }

    try:
        doc = fitz.open(pdf_path)
        page = doc[0]

        picked = _pick_patient_photo(page)
        if picked is not None:
            try:
                img_info = doc.extract_image(picked["xref"])
                image_bytes = img_info.get("image")
                if image_bytes:
                    img = Image.open(io.BytesIO(image_bytes)).convert("RGB")
                    img = _trim_white_border(img)
                    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
                    img.save(output_path, format="PNG")
                    meta["photo_found"] = True
                    meta["method"] = "embedded_image"
            except Exception:
                pass

        # Fallback: crop from known location
        if not meta["photo_found"]:
            try:
                r = page.rect
                clip = fitz.Rect(
                    r.x0 + 0.06 * r.width,
                    r.y0 + 0.24 * r.height,
                    r.x0 + 0.25 * r.width,
                    r.y0 + 0.43 * r.height,
                )
                pix = page.get_pixmap(clip=clip, dpi=220, alpha=False)
                img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
                img = _trim_white_border(img)
                Path(output_path).parent.mkdir(parents=True, exist_ok=True)
                img.save(output_path, format="PNG")
                meta["photo_found"] = True
                meta["method"] = "page_crop_fallback"
            except Exception:
                pass

        doc.close()

    except Exception as e:
        meta["error"] = repr(e)

    return meta
