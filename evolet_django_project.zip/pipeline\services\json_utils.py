"""
JSON utilities — loose parsing, repair, balanced extraction.

Ported from notebook Cell 3 parse_json_loose and helpers.
"""
import re
import ast
import json
import logging
from typing import Any, List

import orjson

logger = logging.getLogger("pipeline")

try:
    from json_repair import repair_json
except ImportError:
    repair_json = None


def _strip_response_wrappers(text: str) -> str:
    text = (text or "").strip()
    text = re.sub(r"^```json\s*", "", text, flags=re.I)
    text = re.sub(r"^```\s*", "", text)
    text = re.sub(r"\s*```$", "", text)
    text = re.sub(r"^<json>\s*", "", text, flags=re.I)
    text = re.sub(r"\s*</json>$", "", text, flags=re.I)
    text = re.sub(r"^\s*assistant\s*[:\-]\s*", "", text, flags=re.I)
    return text.strip()


def _extract_balanced_json_candidates(text: str) -> List[str]:
    candidates = []
    for open_ch, close_ch in [("{", "}"), ("[", "]")]:
        start_positions = [m.start() for m in re.finditer(re.escape(open_ch), text)]
        for start in start_positions:
            depth = 0
            in_string = False
            escape = False
            for idx in range(start, len(text)):
                ch = text[idx]
                if escape:
                    escape = False
                    continue
                if ch == "\\":
                    escape = True
                    continue
                if ch == '"':
                    in_string = not in_string
                    continue
                if in_string:
                    continue
                if ch == open_ch:
                    depth += 1
                elif ch == close_ch:
                    depth -= 1
                    if depth == 0:
                        candidates.append(text[start : idx + 1])
                        break
    seen, uniq = set(), []
    for c in candidates:
        c = c.strip()
        if c and c not in seen:
            seen.add(c)
            uniq.append(c)
    return uniq


def _normalize_jsonish_text(text: str) -> str:
    text = text.strip()
    text = re.sub(r",\s*([}\]])", r"\1", text)
    return text


def parse_json_loose(text: str) -> Any:
    """
    Aggressively parse JSON from LLM output:
    1. Strip code-fence wrappers
    2. Try standard JSON parsers
    3. Try json_repair
    4. Try Python literal_eval fallback
    """
    cleaned = _strip_response_wrappers(text)
    candidates = [cleaned] + _extract_balanced_json_candidates(cleaned)

    for cand in candidates:
        cand = _normalize_jsonish_text(cand)
        for loader in (json.loads, orjson.loads):
            try:
                return loader(cand)
            except Exception:
                pass

    if repair_json is not None:
        for cand in candidates:
            try:
                repaired = repair_json(cand, return_objects=True)
                if isinstance(repaired, (dict, list)):
                    return repaired
            except Exception:
                pass

    for cand in candidates:
        try:
            pyish = cand
            pyish = re.sub(r"\btrue\b", "True", pyish, flags=re.I)
            pyish = re.sub(r"\bfalse\b", "False", pyish, flags=re.I)
            pyish = re.sub(r"\bnull\b", "None", pyish, flags=re.I)
            parsed = ast.literal_eval(pyish)
            if isinstance(parsed, (dict, list)):
                return parsed
        except Exception:
            pass

    preview = cleaned[:500].replace("\n", "\\n")
    raise ValueError(f"Could not parse JSON. Preview: {preview}")


def safe_json_dumps(obj: Any) -> bytes:
    """Write JSON with orjson for speed."""
    return orjson.dumps(obj, option=orjson.OPT_INDENT_2)
