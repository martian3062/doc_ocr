"""
PDF Extractor — Native text + OCR fallback.

Ported from notebook Cells 4-5. Processes one PDF into page-level text.
Supports parallel page rendering via ThreadPoolExecutor.
"""
import io
import re
import hashlib
import logging
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional
from concurrent.futures import ThreadPoolExecutor

import fitz  # PyMuPDF
import torch
from PIL import Image

from . import config

logger = logging.getLogger("pipeline")

# ── OCR engine singleton ──
_ocr_engine = None


def normalize_text(text: str) -> str:
    if not text:
        return ""
    text = str(text).replace("\x00", " ").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def word_count(text: str) -> int:
    return len(re.findall(r"\b\w+\b", text or ""))


def alpha_ratio(text: str) -> float:
    if not text:
        return 0.0
    alpha = sum(ch.isalpha() for ch in text)
    return alpha / max(len(text), 1)


def text_hash(text: str) -> str:
    return hashlib.md5(normalize_text(text).encode("utf-8")).hexdigest()


def _init_ocr():
    """Lazy-load doctr OCR engine (GPU accelerated)."""
    global _ocr_engine
    if _ocr_engine is not None:
        return _ocr_engine
    try:
        from doctr.models import ocr_predictor
        _ocr_engine = ocr_predictor(pretrained=True, assume_straight_pages=True)
        if torch.cuda.is_available():
            _ocr_engine = _ocr_engine.cuda().half()
        _ocr_engine.eval()
        logger.info("Doctr OCR engine loaded (GPU)" if torch.cuda.is_available() else "Doctr OCR engine loaded (CPU)")
    except Exception as e:
        logger.warning(f"Failed to load doctr OCR: {e}")
        _ocr_engine = None
    return _ocr_engine


def _doctr_page_to_text(page_export: Dict[str, Any]) -> str:
    lines_out = []
    for block in page_export.get("blocks", []) or []:
        for line in block.get("lines", []) or []:
            words = []
            for w in line.get("words", []) or []:
                val = normalize_text(w.get("value") or w.get("text") or "")
                if val:
                    words.append(val)
            line_text = " ".join(words).strip()
            if line_text:
                lines_out.append(line_text)
    return "\n".join(lines_out).strip()


def _ocr_images(image_paths: List[str]) -> List[str]:
    """Run OCR on a batch of image paths."""
    engine = _init_ocr()
    if engine is None:
        return [""] * len(image_paths)
    try:
        from doctr.io import DocumentFile
        doc = DocumentFile.from_images(image_paths)
        result = engine(doc).export()
        pages = result.get("pages", []) or []
        return [_doctr_page_to_text(p) for p in pages]
    except Exception as e:
        logger.error(f"OCR batch failed: {e}")
        return [""] * len(image_paths)


def _get_native_page_text(page) -> str:
    """Extract text natively from a PyMuPDF page."""
    parts = []
    try:
        for block in page.get_text("blocks", sort=True):
            if len(block) >= 5 and isinstance(block[4], str):
                t = normalize_text(block[4])
                if t:
                    parts.append(t)
    except Exception:
        pass
    if not parts:
        try:
            t = normalize_text(page.get_text("text", sort=True))
            if t:
                parts.append(t)
        except Exception:
            pass
    return "\n".join(parts).strip()


def _page_needs_ocr(text: str) -> bool:
    text = normalize_text(text)
    if len(text) < config.NATIVE_TEXT_MIN_CHARS:
        return True
    if word_count(text) < config.NATIVE_TEXT_MIN_WORDS:
        return True
    if alpha_ratio(text) < config.NATIVE_TEXT_MIN_ALPHA_RATIO:
        return True
    return False


def extract_pdf_pages(pdf_path: str) -> List[Dict[str, Any]]:
    """
    Extract text from all pages of a PDF.
    Returns list of page dicts with text and metadata.
    Uses native extraction first, falls back to OCR for weak pages.
    """
    doc = fitz.open(pdf_path)
    page_rows = []
    weak_indices = []

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir)

        # ── Phase 1: native extraction + identify weak pages ──
        for i in range(len(doc)):
            page = doc[i]
            page_num = i + 1
            native_text = normalize_text(_get_native_page_text(page))

            row = {
                "page_num": page_num,
                "selected_source": "native",
                "text": native_text,
                "char_count": len(native_text),
                "word_count": word_count(native_text),
                "alpha_ratio": round(alpha_ratio(native_text), 4),
                "need_ocr": False,
            }

            if config.USE_DOCTR_OCR and _page_needs_ocr(native_text):
                img_path = tmp_path / f"page_{page_num:04d}.png"
                pix = page.get_pixmap(dpi=config.OCR_RENDER_DPI, alpha=False)
                pix.save(str(img_path))
                row["need_ocr"] = True
                row["_tmp_image_path"] = str(img_path)
                weak_indices.append(len(page_rows))

            page_rows.append(row)

        # ── Phase 2: batch OCR on weak pages ──
        if config.USE_DOCTR_OCR and weak_indices:
            weak_paths = [page_rows[idx]["_tmp_image_path"] for idx in weak_indices]
            for start in range(0, len(weak_paths), config.OCR_BATCH_PAGES):
                batch_paths = weak_paths[start : start + config.OCR_BATCH_PAGES]
                batch_texts = _ocr_images(batch_paths)
                batch_idxs = weak_indices[start : start + config.OCR_BATCH_PAGES]
                for j, idx in enumerate(batch_idxs):
                    ocr_text = normalize_text(
                        batch_texts[j] if j < len(batch_texts) else ""
                    )
                    if len(ocr_text) > len(page_rows[idx]["text"]):
                        page_rows[idx]["text"] = ocr_text
                        page_rows[idx]["char_count"] = len(ocr_text)
                        page_rows[idx]["word_count"] = word_count(ocr_text)
                        page_rows[idx]["alpha_ratio"] = round(alpha_ratio(ocr_text), 4)
                        page_rows[idx]["selected_source"] = "ocr"

        # Clean up temp paths
        for row in page_rows:
            row.pop("_tmp_image_path", None)

    doc.close()
    return page_rows


def extract_text_from_uploaded_file(file_bytes: bytes, filename: str) -> str:
    """Extract text from an uploaded file (PDF or plain text)."""
    if filename.lower().endswith(".pdf"):
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        texts = []
        for i in range(len(doc)):
            texts.append(normalize_text(_get_native_page_text(doc[i])))
        doc.close()
        return "\n\n".join(texts)
    else:
        # Assume plain text
        try:
            return file_bytes.decode("utf-8")
        except UnicodeDecodeError:
            return file_bytes.decode("latin-1")
