"""
QC — Quality control metrics for extraction runs.

Ported from notebook Cell 13.
"""
import logging
from typing import Any, Dict, List

logger = logging.getLogger("pipeline")


def compute_qc_metrics(final_record: Dict[str, Any]) -> Dict[str, Any]:
    """Compute quality metrics for one patient's final record."""
    mentions = final_record.get("mentions", [])
    grouped = final_record.get("grouped_record", {})
    trace = final_record.get("traceability", {})
    stats = final_record.get("stats", {})

    return {
        "patient_code": final_record.get("patient_code", ""),
        "source_pdf": final_record.get("source_pdf", ""),
        "mention_count": len(mentions),
        "category_count": len(grouped),
        "trace_pages": len(trace.get("source_pages", [])),
        "trace_evidence_ids": len(trace.get("evidence_ids", [])),
        "review_flags": len(final_record.get("review_flags", [])),
        "raw_mentions_before_merge": stats.get("raw_mentions_before_merge", 0),
        "mentions_after_merge": stats.get("mentions_after_merge", 0),
        "categories": list(grouped.keys()),
        "has_diagnosis": "diagnosis" in grouped,
        "has_medication": "medication" in grouped,
        "has_imaging": "imaging" in grouped,
        "has_pathology": "pathology" in grouped,
    }


def compute_run_summary(qc_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Compute aggregate QC summary across all patients."""
    if not qc_rows:
        return {"total_patients": 0}

    total = len(qc_rows)
    mention_counts = [r["mention_count"] for r in qc_rows]
    flagged = sum(1 for r in qc_rows if r["review_flags"] > 0)

    return {
        "total_patients": total,
        "total_mentions": sum(mention_counts),
        "avg_mentions_per_patient": round(sum(mention_counts) / total, 1),
        "min_mentions": min(mention_counts),
        "max_mentions": max(mention_counts),
        "patients_with_flags": flagged,
        "patients_with_diagnosis": sum(1 for r in qc_rows if r["has_diagnosis"]),
        "patients_with_medication": sum(1 for r in qc_rows if r["has_medication"]),
        "patients_with_imaging": sum(1 for r in qc_rows if r["has_imaging"]),
        "patients_with_pathology": sum(1 for r in qc_rows if r["has_pathology"]),
    }
