"""
LLM Engine — Qwen model loading, prompt construction, batch inference.

Ported from notebook Cells 8-9. Uses singleton pattern for model management.
Supports 4-bit quantization on L4 24GB GPU.
"""
import time
import logging
from typing import Any, Dict, List, Optional

import torch

from . import config
from .pdf_extractor import normalize_text, word_count
from .note_segmenter import extract_dates
from .json_utils import parse_json_loose
from .gpu_utils import detect_compute_dtype, release_cuda

logger = logging.getLogger("pipeline")

# ── Singleton model holder ──
_model = None
_tokenizer = None
_model_id = None


def load_model(model_id: str = None, force_reload: bool = False):
    """Load or return cached LLM + tokenizer."""
    global _model, _tokenizer, _model_id

    model_id = model_id or config.MODEL_ID

    if _model is not None and _model_id == model_id and not force_reload:
        return _tokenizer, _model

    # Unload existing
    unload_model()

    from transformers import (
        AutoTokenizer,
        AutoModelForCausalLM,
        BitsAndBytesConfig,
        GenerationConfig,
    )

    compute_dtype = detect_compute_dtype()
    logger.info(f"Loading model: {model_id} | dtype={compute_dtype} | 4bit={config.USE_4BIT}")

    common_kwargs = {"local_files_only": config.LOCAL_FILES_ONLY}
    if config.HF_TOKEN:
        common_kwargs["token"] = config.HF_TOKEN

    tokenizer = AutoTokenizer.from_pretrained(
        model_id, use_fast=True, **common_kwargs
    )
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    tokenizer.padding_side = "left"
    tokenizer.truncation_side = "left"

    quant_config = None
    if config.USE_4BIT and torch.cuda.is_available():
        quant_config = BitsAndBytesConfig(
            load_in_4bit=True,
            bnb_4bit_compute_dtype=compute_dtype,
            bnb_4bit_quant_type="nf4",
            bnb_4bit_use_double_quant=True,
        )

    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        quantization_config=quant_config,
        torch_dtype=compute_dtype,
        device_map="auto",
        low_cpu_mem_usage=True,
        attn_implementation="sdpa",
        **common_kwargs,
    )
    model.eval()
    model.config.use_cache = True

    gen_cfg = GenerationConfig.from_model_config(model.config)
    gen_cfg.do_sample = config.DO_SAMPLE
    gen_cfg.max_new_tokens = config.MAX_NEW_TOKENS
    gen_cfg.use_cache = True
    gen_cfg.pad_token_id = tokenizer.pad_token_id
    gen_cfg.eos_token_id = tokenizer.eos_token_id
    model.generation_config = gen_cfg

    _model = model
    _tokenizer = tokenizer
    _model_id = model_id
    logger.info(f"Model loaded: {model_id}")
    return _tokenizer, _model


def unload_model():
    """Free model from memory."""
    global _model, _tokenizer, _model_id
    if _model is not None:
        del _model
    if _tokenizer is not None:
        del _tokenizer
    _model = None
    _tokenizer = None
    _model_id = None
    release_cuda()
    logger.info("Model unloaded")


def is_model_loaded() -> bool:
    return _model is not None


# ── Prompt construction ──

def _trim_note_text(text: str, max_chars: int = 9000) -> str:
    text = normalize_text(text)
    if len(text) <= max_chars:
        return text
    head = int(max_chars * 0.65)
    tail = max_chars - head - 32
    return (
        text[:head].rstrip()
        + "\n\n...[middle truncated for token budget]...\n\n"
        + text[-tail:].lstrip()
    )


def _build_prompt(note: Dict[str, Any]) -> str:
    note_text = _trim_note_text(note["text"])
    return f"""note_id={note["note_id"]}
page_num={note["page_num"]}
regex_mentions_already_found={len(note.get("regex_mentions", []))}

Extract clinically useful mentions from this note and return JSON only.

note_text:
{note_text}""".strip()


# ── Batching ──

def _note_bucket(note: Dict[str, Any]) -> str:
    wc = word_count(note.get("text", ""))
    if wc <= config.SHORT_NOTE_WORDS:
        return "short"
    if wc <= config.MEDIUM_NOTE_WORDS:
        return "medium"
    if wc <= config.LONG_NOTE_WORDS:
        return "long"
    return "xlong"


def _batch_size_for(bucket: str) -> int:
    return {
        "short": config.SHORT_BATCH_SIZE,
        "medium": config.MEDIUM_BATCH_SIZE,
        "long": config.LONG_BATCH_SIZE,
        "xlong": config.XLONG_BATCH_SIZE,
    }.get(bucket, 1)


def _max_tokens_for(bucket: str) -> int:
    return config.RETRY_MAX_NEW_TOKENS if bucket in {"long", "xlong"} else config.MAX_NEW_TOKENS


def _make_batches(notes: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    if not notes:
        return []
    ordered = sorted(
        notes,
        key=lambda n: (
            ["short", "medium", "long", "xlong"].index(_note_bucket(n)),
            word_count(n.get("text", "")),
        ),
    )
    out, current, current_bucket = [], [], None
    for note in ordered:
        bucket = _note_bucket(note)
        limit = _batch_size_for(bucket)
        if current and (bucket != current_bucket or len(current) >= limit):
            out.append({
                "bucket": current_bucket,
                "max_new_tokens": _max_tokens_for(current_bucket),
                "notes": current,
            })
            current = []
        current_bucket = bucket
        current.append(note)
    if current:
        out.append({
            "bucket": current_bucket,
            "max_new_tokens": _max_tokens_for(current_bucket),
            "notes": current,
        })
    return out


# ── Generation ──

def _generate_batch(
    prompts: List[str],
    max_new_tokens: int = config.MAX_NEW_TOKENS,
) -> List[str]:
    """Run batch generation on loaded model."""
    tokenizer, model = _tokenizer, _model
    if tokenizer is None or model is None:
        raise RuntimeError("Model not loaded. Call load_model() first.")

    rendered = [
        tokenizer.apply_chat_template(
            [
                {"role": "system", "content": config.SYSTEM_PROMPT},
                {"role": "user", "content": p},
            ],
            tokenize=False,
            add_generation_prompt=True,
        )
        for p in prompts
    ]

    inputs = tokenizer(
        rendered,
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=config.MAX_INPUT_TOKENS,
    )
    padded_len = inputs["input_ids"].shape[1]
    device = next(model.parameters()).device
    inputs = {k: v.to(device) for k, v in inputs.items()}

    start_t = time.time()
    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=config.DO_SAMPLE,
            use_cache=True,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )
    took = time.time() - start_t
    logger.info(
        f"LLM batch={len(prompts)} prompt_tokens={padded_len} "
        f"max_new={max_new_tokens} time={took:.1f}s"
    )

    decoded = []
    for i in range(outputs.shape[0]):
        new_tokens = outputs[i][padded_len:]
        text = tokenizer.decode(new_tokens, skip_special_tokens=True).strip()
        decoded.append(text)
    return decoded


# ── Mention cleaning ──

def _clean_llm_mention(raw: Dict[str, Any], note: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not isinstance(raw, dict):
        return None
    value = normalize_text(raw.get("value", ""))
    label = normalize_text(raw.get("label", ""))
    if not value and not label:
        return None
    category = normalize_text(raw.get("category", "")) or "unknown"
    certainty = str(raw.get("certainty", "unknown")).strip().lower()
    if certainty not in {"confirmed", "possible", "ruled_out", "unknown"}:
        certainty = "unknown"
    return {
        "category": category,
        "label": label or category,
        "value": value or label,
        "normalized_value": normalize_text(raw.get("normalized_value", "")) or value or label,
        "date_text": normalize_text(raw.get("date_text", "")) or (
            extract_dates(note["text"])[0] if extract_dates(note["text"]) else ""
        ),
        "certainty": certainty,
        "attributes": raw.get("attributes", {}) if isinstance(raw.get("attributes"), dict) else {},
        "source_pages": [note["page_num"]],
        "evidence_ids": [note["note_id"]],
        "evidence_quote": normalize_text(raw.get("evidence_quote", ""))[:240],
        "origin": "llm",
    }


def _parse_mentions(raw_text: str, note: Dict[str, Any]) -> List[Dict[str, Any]]:
    parsed = parse_json_loose(raw_text)
    mentions = parsed.get("mentions", []) if isinstance(parsed, dict) else []
    cleaned = [_clean_llm_mention(x, note) for x in mentions]
    return [x for x in cleaned if x is not None]


# ── Public API ──

def process_unresolved_notes(
    unresolved_notes: List[Dict[str, Any]],
    progress_callback=None,
) -> List[Dict[str, Any]]:
    """
    Process all unresolved notes through the LLM with adaptive batching.
    Returns list of extracted mention dicts.
    """
    if not unresolved_notes:
        return []

    all_mentions = []
    failures = []
    batches = _make_batches(unresolved_notes)
    total_batches = len(batches)

    for batch_idx, batch_info in enumerate(batches):
        batch_notes = batch_info["notes"]
        prompts = [_build_prompt(n) for n in batch_notes]

        try:
            outputs = _generate_batch(prompts, max_new_tokens=batch_info["max_new_tokens"])
        except Exception as e:
            logger.error(f"LLM batch failed: {e}")
            failures.extend([{"note_id": n["note_id"], "error": str(e)} for n in batch_notes])
            continue

        for note, raw_text in zip(batch_notes, outputs):
            try:
                mentions = _parse_mentions(raw_text, note)
                all_mentions.extend(mentions)
            except Exception as e:
                # Retry once with higher token budget
                try:
                    retry_out = _generate_batch(
                        [_build_prompt(note)],
                        max_new_tokens=config.RETRY_MAX_NEW_TOKENS,
                    )[0]
                    mentions = _parse_mentions(retry_out, note)
                    all_mentions.extend(mentions)
                except Exception as retry_e:
                    failures.append({
                        "note_id": note["note_id"],
                        "error": str(e),
                        "retry_error": str(retry_e),
                    })

        if progress_callback:
            progress_callback(batch_idx + 1, total_batches)

    if failures:
        logger.warning(f"LLM failures: {len(failures)}")

    return all_mentions
