"""
Regex Extractor — Deterministic mention extraction from clinical notes.

Ported from notebook Cell 6 simple_extract_note_mentions.
Covers: diagnosis, pathology, imaging, medications, symptoms, labs,
genomics, plan blocks, follow-up, performance status, surgery, radiotherapy.
"""
import re
import logging
from typing import Any, Dict, List, Optional

from .pdf_extractor import normalize_text, word_count
from .note_segmenter import extract_dates

logger = logging.getLogger("pipeline")

LINE_BREAK_RE = re.compile(r"\n+")


def first_date_or_blank(text: str) -> str:
    ds = extract_dates(text)
    return ds[0] if ds else ""


def _add_mention(
    out: List[Dict[str, Any]],
    note: Dict[str, Any],
    category: str,
    label: str,
    value: str,
    certainty: str = "confirmed",
    attributes: Optional[Dict[str, Any]] = None,
    evidence_quote: Optional[str] = None,
):
    value = normalize_text(value)
    label = normalize_text(label)
    if not value:
        return
    out.append(
        {
            "category": category or "unknown",
            "label": label,
            "value": value,
            "normalized_value": value,
            "date_text": first_date_or_blank(note["text"]),
            "certainty": certainty,
            "attributes": attributes or {},
            "source_pages": [note["page_num"]],
            "evidence_ids": [note["note_id"]],
            "evidence_quote": normalize_text(evidence_quote or value[:240]),
            "origin": "regex",
        }
    )


def _extract_plan_block(text: str) -> str:
    lines = [normalize_text(x) for x in LINE_BREAK_RE.split(text)]
    lines = [x for x in lines if x]
    out = []
    capture = False
    for line in lines:
        low = line.lower()
        if re.match(r"^(plan|tentative plan|adv|remarks / others)\s*[:\-]?$", low):
            capture = True
            continue
        if capture:
            if re.match(
                r"^(date|clinical note details|patient assessment details|"
                r"joint-clinic details|entered by|seen by)\b",
                low,
            ):
                break
            out.append(line)
            if len(out) >= 6:
                break
    return normalize_text(" | ".join(out))


def extract_note_mentions(note: Dict[str, Any]) -> List[Dict[str, Any]]:
    """
    Run all deterministic regex extractors on a single note.
    Returns a list of mention dicts.
    """
    text = note["text"]
    low = text.lower()
    mentions: List[Dict[str, Any]] = []

    # ── Diagnosis ──
    for pat in [
        r"final diagnosis\s*[:\-]\s*(.+)",
        r"diagnosis\s*[:\-]\s*(.+)",
        r"imp\s*[-:]\s*(.+)",
        r"impression\s*[:\-]\s*(.+)",
        r"case of\s+(.+)",
    ]:
        m = re.search(pat, text, flags=re.I)
        if m:
            val = normalize_text(m.group(1))
            val = re.split(r"\n|\|", val)[0]
            _add_mention(mentions, note, "diagnosis", "diagnosis", val, evidence_quote=val)
            break

    # ── Pathology ──
    for pat, label in [
        (r"(hpr[^\n:]*[:\-]\s*.+)", "HPR"),
        (r"(histopath[^\n:]*[:\-]\s*.+)", "histopathology"),
        (r"(ihc[^\n:]*[:\-]\s*.+)", "IHC"),
    ]:
        for m in re.finditer(pat, text, flags=re.I):
            val = normalize_text(m.group(1))
            _add_mention(mentions, note, "pathology", label, val, evidence_quote=val)

    # ── Imaging ──
    for pat, label in [
        (r"(pet ct[^\n]*[:\-]?\s*.+)", "PET CT"),
        (r"(c?ect[^\n]*[:\-]?\s*.+)", "CECT"),
        (r"(mri[^\n]*[:\-]?\s*.+)", "MRI"),
        (r"(ct study reveals[^\n]*[:\-]?\s*.+)", "CT"),
    ]:
        for m in re.finditer(pat, text, flags=re.I):
            val = normalize_text(m.group(1))
            _add_mention(mentions, note, "imaging", label, val, evidence_quote=val)

    # ── Medications ──
    for m in re.finditer(
        r"((tab|t\.)\s*[A-Z][A-Za-z0-9.+-]*(?:\s+[A-Za-z0-9.+-]+){0,4}"
        r"\s*(?:\d+(?:\.\d+)?)?\s*(?:mg|mcg|gm)?[^\n]*)",
        text,
        flags=re.I,
    ):
        val = normalize_text(m.group(1))
        if len(val) >= 5:
            _add_mention(mentions, note, "medication", "medication", val, evidence_quote=val)

    for drug in [
        "sunitinib", "everolimus", "pazopanib", "nivolumab",
        "cabozantinib", "chemotherapy",
    ]:
        if re.search(rf"\b{drug}\b", low):
            line = next(
                (ln.strip() for ln in text.splitlines() if drug in ln.lower()),
                drug,
            )
            _add_mention(mentions, note, "medication", "drug", line, evidence_quote=line)

    # ── Symptoms ──
    for m in re.finditer(r"(c/o\s*[-:]?\s*[^\n]+)", text, flags=re.I):
        _add_mention(mentions, note, "symptom", "complaint", m.group(1), evidence_quote=m.group(1))
    for m in re.finditer(r"(pain[^\n]{0,120})", text, flags=re.I):
        _add_mention(mentions, note, "symptom", "pain", m.group(1), evidence_quote=m.group(1))

    # ── Performance status ──
    for m in re.finditer(r"\b(PS\s*[-:]?\s*\d)\b", text, flags=re.I):
        _add_mention(mentions, note, "performance_status", "PS", m.group(1), evidence_quote=m.group(1))
    for m in re.finditer(r"\b(KPS\s*\d{2,3})\b", text, flags=re.I):
        _add_mention(mentions, note, "performance_status", "KPS", m.group(1), evidence_quote=m.group(1))

    # ── Surgery / Radiotherapy ──
    for key, category in [
        ("nephrectomy", "surgery"),
        ("surgery", "surgery"),
        ("rt", "radiotherapy"),
        ("radiotherapy", "radiotherapy"),
        ("sbrt", "radiotherapy"),
    ]:
        if re.search(rf"\b{re.escape(key)}\b", low):
            line = next(
                (ln.strip() for ln in text.splitlines() if key in ln.lower()),
                key,
            )
            _add_mention(mentions, note, category, key, line, evidence_quote=line)

    # ── Labs ──
    for m in re.finditer(r"\b(serum creat\s*\d+(?:\.\d+)?)\b", low, flags=re.I):
        _add_mention(mentions, note, "lab", "serum creatinine", m.group(1), evidence_quote=m.group(1))

    # ── Genomics ──
    for m in re.finditer(r"\b(NGS\s*[:\-]?\s*[^\n]+)\b", text, flags=re.I):
        _add_mention(mentions, note, "genomics", "NGS", m.group(1), evidence_quote=m.group(1))

    # ── Plan ──
    plan_block = _extract_plan_block(text)
    if plan_block:
        _add_mention(mentions, note, "plan", "plan", plan_block, evidence_quote=plan_block)

    # ── Follow-up ──
    for m in re.finditer(
        r"(review after[^\n]+|r/s[^\n]+|follow[- ]?up[^\n]+)", text, flags=re.I
    ):
        _add_mention(mentions, note, "follow_up", "follow_up", m.group(1), evidence_quote=m.group(1))

    # ── Dedup ──
    seen, out = set(), []
    for x in mentions:
        key = (x["category"], x["label"].lower(), x["value"].lower())
        if key not in seen:
            seen.add(key)
            out.append(x)
    return out


def extract_all_notes(notes: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
    """Run regex extraction on all notes, return {note_id: [mentions]}."""
    results = {}
    for note in notes:
        results[note["note_id"]] = extract_note_mentions(note)
    return results
