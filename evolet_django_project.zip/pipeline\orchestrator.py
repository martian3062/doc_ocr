"""
Pipeline Orchestrator — Runs the complete extraction pipeline.

Ties together all services: extract → segment → triage → LLM → merge → QC.
Supports parallel PDF processing with ThreadPoolExecutor.
"""
import logging
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import List, Optional

from django.utils import timezone

from .models import (
    Patient, PDFDocument, PipelineRun, PageLedger, NoteLedger,
    Mention, FinalRecord, ProcessingLog,
)
from .services import config
from .services.pdf_extractor import extract_pdf_pages, normalize_text, word_count
from .services.note_segmenter import segment_pages_to_notes, extract_dates
from .services.regex_extractor import extract_all_notes, extract_note_mentions
from .services.note_segmenter import triage_notes
from .services.llm_engine import load_model, process_unresolved_notes, unload_model
from .services.merger import build_final_record, merge_mentions
from .services.qc import compute_qc_metrics
from .services.photo_extractor import extract_profile_photo
from .services.gpu_utils import setup_gpu, release_cuda

logger = logging.getLogger("pipeline")


def _log(run: PipelineRun, level: str, stage: str, message: str, details: dict = None):
    ProcessingLog.objects.create(
        run=run, level=level, stage=stage, message=message,
        details=details or {},
    )


def _update_run(run: PipelineRun, **kwargs):
    for k, v in kwargs.items():
        setattr(run, k, v)
    run.save(update_fields=list(kwargs.keys()))


def process_single_document(doc: PDFDocument, run: PipelineRun) -> dict:
    """
    Process a single PDF document through the full pipeline (except LLM).
    LLM is run separately to manage GPU memory.
    """
    patient = doc.patient
    pdf_path = doc.folder_path or doc.file.path

    result = {
        "patient_code": patient.code,
        "status": "ok",
        "page_count": 0,
        "note_count": 0,
        "resolved": 0,
        "unresolved": 0,
        "regex_mentions": 0,
    }

    try:
        # ── Stage 1: Extract pages ──
        page_rows = extract_pdf_pages(pdf_path)
        result["page_count"] = len(page_rows)
        doc.page_count = len(page_rows)
        doc.save(update_fields=["page_count"])

        # Save page ledgers to DB
        PageLedger.objects.filter(document=doc).delete()
        page_objects = [
            PageLedger(
                document=doc,
                page_num=row["page_num"],
                text=row["text"],
                selected_source=row["selected_source"],
                char_count=row["char_count"],
                word_count=row["word_count"],
                alpha_ratio=row["alpha_ratio"],
                need_ocr=row["need_ocr"],
            )
            for row in page_rows
        ]
        PageLedger.objects.bulk_create(page_objects)

        # ── Stage 2: Segment into notes ──
        notes = segment_pages_to_notes(page_rows)
        result["note_count"] = len(notes)

        # ── Stage 3: Regex extraction + triage ──
        regex_results = extract_all_notes(notes)
        result["regex_mentions"] = sum(len(v) for v in regex_results.values())

        triaged = triage_notes(notes, regex_results)
        result["resolved"] = len(triaged["resolved"])
        result["unresolved"] = len(triaged["unresolved"])

        # Save notes to DB
        NoteLedger.objects.filter(document=doc).delete()
        note_objects = []
        for note in notes:
            note_id = note["note_id"]
            is_resolved = note_id not in {n["note_id"] for n in triaged["unresolved"]}
            note_objects.append(
                NoteLedger(
                    document=doc,
                    note_id=note_id,
                    page_num=note["page_num"],
                    note_ix=note["note_ix"],
                    text=note["text"],
                    text_hash=note["hash"],
                    signal_score=note["signal"],
                    is_low_value=note["low_value"],
                    needs_llm=not is_resolved and note_id in {n["note_id"] for n in triaged["unresolved"]},
                    is_resolved=is_resolved,
                )
            )
        NoteLedger.objects.bulk_create(note_objects)

        # Save regex mentions
        Mention.objects.filter(patient=patient, run=run, origin="regex").delete()
        mention_objects = []
        for resolved_note in triaged["resolved"]:
            for m in resolved_note.get("mentions", []):
                mention_objects.append(
                    Mention(
                        patient=patient,
                        document=doc,
                        run=run,
                        category=m["category"],
                        label=m["label"],
                        value=m["value"],
                        normalized_value=m["normalized_value"],
                        date_text=m.get("date_text", ""),
                        certainty=m.get("certainty", "unknown"),
                        attributes=m.get("attributes", {}),
                        evidence_quote=m.get("evidence_quote", ""),
                        source_pages=m.get("source_pages", []),
                        evidence_ids=m.get("evidence_ids", []),
                        origin="regex",
                    )
                )
        if mention_objects:
            Mention.objects.bulk_create(mention_objects)

        # Store unresolved notes data in session for LLM phase
        result["unresolved_notes_data"] = triaged["unresolved"]

        _log(run, "info", "extraction",
             f"{patient.code}: {len(page_rows)} pages, {len(notes)} notes, "
             f"{result['resolved']} resolved, {result['unresolved']} unresolved")

    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)
        _log(run, "error", "extraction",
             f"{patient.code}: {str(e)}", {"traceback": traceback.format_exc()})

    return result


def run_llm_phase(
    run: PipelineRun,
    doc_results: List[dict],
):
    """Run LLM inference on all unresolved notes across all documents."""
    _update_run(run, status=PipelineRun.Status.LLM_PROCESSING)

    # Collect all unresolved notes
    all_unresolved = []
    patient_map = {}  # note_id -> (patient, doc)
    for res in doc_results:
        if res["status"] != "ok":
            continue
        patient_code = res["patient_code"]
        unresolved = res.get("unresolved_notes_data", [])
        for note in unresolved:
            all_unresolved.append(note)
            patient_map[note["note_id"]] = patient_code

    if not all_unresolved:
        logger.info("No unresolved notes — skipping LLM phase")
        return

    logger.info(f"LLM phase: {len(all_unresolved)} unresolved notes")

    # Load model
    try:
        load_model()
    except Exception as e:
        _log(run, "error", "llm", f"Model load failed: {e}")
        return

    def _progress(done, total):
        _log(run, "info", "llm", f"Batch {done}/{total}")

    try:
        llm_mentions = process_unresolved_notes(
            all_unresolved, progress_callback=_progress
        )

        # Save LLM mentions
        mention_objects = []
        for m in llm_mentions:
            note_id = m.get("evidence_ids", [""])[0] if m.get("evidence_ids") else ""
            patient_code = patient_map.get(note_id, "")
            if not patient_code:
                continue
            try:
                patient = Patient.objects.get(code=patient_code)
                doc = patient.documents.first()
            except Patient.DoesNotExist:
                continue

            mention_objects.append(
                Mention(
                    patient=patient,
                    document=doc,
                    run=run,
                    category=m["category"],
                    label=m["label"],
                    value=m["value"],
                    normalized_value=m["normalized_value"],
                    date_text=m.get("date_text", ""),
                    certainty=m.get("certainty", "unknown"),
                    attributes=m.get("attributes", {}),
                    evidence_quote=m.get("evidence_quote", ""),
                    source_pages=m.get("source_pages", []),
                    evidence_ids=m.get("evidence_ids", []),
                    origin="llm",
                )
            )

        if mention_objects:
            Mention.objects.bulk_create(mention_objects)

        _update_run(run, total_mentions=run.total_mentions + len(llm_mentions))
        _log(run, "info", "llm", f"LLM extracted {len(llm_mentions)} mentions")

    except Exception as e:
        _log(run, "error", "llm", f"LLM phase failed: {e}",
             {"traceback": traceback.format_exc()})
    finally:
        unload_model()


def run_merge_phase(run: PipelineRun):
    """Merge all mentions per patient into final records."""
    _update_run(run, status=PipelineRun.Status.MERGING)

    patients = Patient.objects.filter(
        documents__runs=run
    ).distinct()

    for patient in patients:
        try:
            mentions = list(
                Mention.objects.filter(patient=patient, run=run).values(
                    "category", "label", "value", "normalized_value",
                    "date_text", "certainty", "attributes",
                    "evidence_quote", "source_pages", "evidence_ids", "origin",
                )
            )

            doc = patient.documents.first()
            page_count = PageLedger.objects.filter(document=doc).count() if doc else 0
            note_count = NoteLedger.objects.filter(document=doc).count() if doc else 0

            final_data = build_final_record(
                patient_code=patient.code,
                source_pdf=doc.original_filename if doc else "",
                page_count=page_count,
                note_count=note_count,
                all_mentions=mentions,
            )

            FinalRecord.objects.update_or_create(
                patient=patient,
                defaults={
                    "run": run,
                    "page_count": final_data["page_count"],
                    "note_count": final_data["note_count"],
                    "mention_count": final_data["stats"]["mentions_after_merge"],
                    "category_count": final_data["stats"]["categories_after_merge"],
                    "grouped_record": final_data["grouped_record"],
                    "review_flags": final_data["review_flags"],
                    "traceability": final_data["traceability"],
                    "stats": final_data["stats"],
                },
            )

        except Exception as e:
            _log(run, "error", "merge", f"Merge failed for {patient.code}: {e}")


def run_full_pipeline(run: PipelineRun):
    """Execute the complete pipeline on all documents in the run."""
    setup_gpu()
    _update_run(run, started_at=timezone.now(), status=PipelineRun.Status.EXTRACTING)

    documents = list(run.documents.all())
    _update_run(run, total_pdfs=len(documents))

    # ── Phase 1: Extract + Triage (parallel for I/O) ──
    doc_results = []
    for i, doc in enumerate(documents):
        try:
            result = process_single_document(doc, run)
            doc_results.append(result)
            _update_run(
                run,
                processed_pdfs=i + 1,
                total_notes=run.total_notes + result.get("note_count", 0),
                resolved_notes=run.resolved_notes + result.get("resolved", 0),
                unresolved_notes=run.unresolved_notes + result.get("unresolved", 0),
                total_mentions=run.total_mentions + result.get("regex_mentions", 0),
            )
        except Exception as e:
            _log(run, "error", "extraction", f"Doc {doc.original_filename}: {e}")
            doc_results.append({"patient_code": doc.patient.code, "status": "error", "error": str(e)})

    release_cuda()

    # ── Phase 2: LLM on unresolved notes ──
    _update_run(run, status=PipelineRun.Status.LLM_PROCESSING)
    run_llm_phase(run, doc_results)
    release_cuda()

    # ── Phase 3: Merge ──
    run_merge_phase(run)

    # ── Phase 4: Profile photos ──
    for doc in documents:
        try:
            pdf_path = doc.folder_path or doc.file.path
            output_path = f"media/profile_images/{doc.patient.code}.png"
            meta = extract_profile_photo(pdf_path, output_path)
            if meta["photo_found"]:
                doc.patient.profile_image = f"profile_images/{doc.patient.code}.png"
                doc.patient.save(update_fields=["profile_image"])
        except Exception:
            pass

    # ── Done ──
    _update_run(
        run,
        status=PipelineRun.Status.COMPLETED,
        completed_at=timezone.now(),
    )
    _log(run, "info", "complete",
         f"Pipeline completed: {len(documents)} PDFs, "
         f"{run.total_mentions} mentions")
